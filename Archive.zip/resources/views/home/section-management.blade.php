<div class="hbox text-center text-sm">          
    <a href="{{ url('kelola-data/posisi-kas') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-random block m-b-xs fa-2x"></i>
        <span>Posisi Kas</span>
    </a>
    <a href="{{ url('kelola-data/outflow') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-upload block m-b-xs fa-2x"></i>
        <span>Outflow</span>
    </a>
    <a href="{{ url('kelola-data/inflow') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-download block m-b-xs fa-2x"></i>
        <span>Inflow</span>
    </a>   
    <a href="{{ url('kelola-data/pemusnahan') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-fire block m-b-xs fa-2x"></i>
        <span>Pemusnahan</span>
    </a>
    {{-- <a href="{{ url('kelola-data/uyd') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-money block m-b-xs fa-2x"></i>
        <span>UYD</span>
    </a> --}}
    {{-- <a href="{{ url('kelola-data/uyd-pecahan') }}" class="col padder-v text-muted b-r b-light">
        <i class="icon-wallet block m-b-xs fa-2x"></i>
        <span>UYD Pecahan</span>
    </a> --}}
    <a href="{{ url('kelola-data/proyeksi') }}" class="col padder-v text-muted b-r b-light">
        <i class="fa fa-line-chart block m-b-xs fa-2x"></i>
        <span>Proyeksi</span>
    </a>   
    <a href="{{ url('kelola-data/survei') }}" class="col padder-v text-muted">
        <i class="fa fa-list block m-b-xs fa-2x"></i>
        <span>Survey</span>
    </a>
    <a href="#" class="col padder-v text-muted b-r b-light">
        {{-- <i class="icon-wallet block m-b-xs fa-2x"></i>
        <span>UYD Pecahan</span> --}}
    </a>
    <a href="#" class="col padder-v text-muted b-r b-light">
        {{-- <i class="icon-wallet block m-b-xs fa-2x"></i>
        <span>UYD Pecahan</span> --}}
    </a>
</div>